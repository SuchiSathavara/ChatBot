package com.example.chatbot;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.riversun.okhttp3.OkHttp3CookieHelper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Cookie;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class MainActivity extends AppCompatActivity {

    // creating variables for our
    // widgets in xml file.
    private RecyclerView chatsRV;
    private ImageButton sendMsgIB;
    private EditText userMsgEdt;
    private final String USER_KEY = "user";
    private final String BOT_KEY = "bot";
    String botResponse;

    // creating a variable for
    // our volley request queue.


    // creating a variable for array list and adapter class.
    private ArrayList<MessageStorage> messageModalArrayList;
    private MessageRVAdapter messageRVAdapter;
    private OkHttp3CookieHelper cookieHelper = new OkHttp3CookieHelper();

    String url = "http://192.168.0.100:5000/bot";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // on below line we are initializing all our views.
        chatsRV = (RecyclerView) findViewById(R.id.idRVChats);
        sendMsgIB = (FloatingActionButton) findViewById(R.id.idIBSend);
        userMsgEdt = findViewById(R.id.idEdtMessage);



        // creating a new array list
        messageModalArrayList = new ArrayList<>();

        // adding on click listener for send message button.
        sendMsgIB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // checking if the message entered
                // by user is empty or not.
                if (userMsgEdt.getText().toString().isEmpty()) {
                    // if the edit text is empty display a toast message.
                    Toast.makeText(MainActivity.this, "Please enter your message..", Toast.LENGTH_SHORT).show();
                    return;
                }

                // calling a method to send message
                // to our bot to get response.
                sendMessage(userMsgEdt.getText().toString());

                // below line we are setting text in our edit text as empty
                userMsgEdt.setText("");
            }
        });

        // on below line we are initializing our adapter class and passing our array list to it.
        messageRVAdapter = new MessageRVAdapter(messageModalArrayList, this);

        // below line we are creating a variable for our linear layout manager.
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MainActivity.this, RecyclerView.VERTICAL, false);

        // below line is to set layout
        // manager to our recycler view.
        chatsRV.setLayoutManager(linearLayoutManager);

        // below line we are setting
        // adapter to our recycler view.
        chatsRV.setAdapter(messageRVAdapter);
    }

    private void sendMessage(String userMsg) {
        // below line is to pass message to our
        // array list which is entered by the user.
        messageModalArrayList.add(new MessageStorage(userMsg, USER_KEY));
        messageRVAdapter.notifyDataSetChanged();

        chatsRV.post(new Runnable() {
            @Override
            public void run() {
                chatsRV.smoothScrollToPosition(messageRVAdapter.getItemCount() - 1);
            }
        });

        System.out.println(userMsg);

        OkHttpClient client = new OkHttpClient
                                    .Builder()
                                    .cookieJar(cookieHelper.cookieJar())
                                    .build();

        RequestBody body = RequestBody.create(MediaType.get("text/plain"),userMsg);

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();


        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onResponse(@NonNull Call call, @NonNull okhttp3.Response response) throws IOException {
                botResponse = response.body().string();
//                List<String> val = response.headers().values("Set-Cookie");
                List<Cookie> c = Cookie.parseAll(HttpUrl.parse(url),response.headers());
                for(int i=0;i<c.size();i++)
                    cookieHelper.setCookie(url,c.get(i));



                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        messageModalArrayList.add(new MessageStorage(botResponse, BOT_KEY));
                        messageRVAdapter.notifyDataSetChanged();
                    }
                });


                response.close();
            }

            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
                System.out.println("Failure");
            }
        });
//        while(botResponse != null) {
//
//            botResponse = null;
//        }
    }
}
